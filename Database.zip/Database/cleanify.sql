-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2025 at 10:05 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cleanify`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` mediumtext DEFAULT NULL,
  `contact_preference` enum('phone','email','whatsapp') DEFAULT 'whatsapp',
  `property_type` enum('apartment','house','office','other') DEFAULT 'apartment',
  `property_size_sqm` int(11) DEFAULT NULL,
  `full_address` mediumtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `contact_preference`, `property_type`, `property_size_sqm`, `full_address`, `created_at`, `updated_at`) VALUES
(1, 'Gorgon Budiono', 'gorgon@gmail.com', '081234567890', 'Jl. Merdeka No. 12', 'whatsapp', 'house', 120, 'Jl. Merdeka No. 12, Jakarta', '2025-11-19 20:54:45', '2025-11-19 20:54:45'),
(2, 'Jibril Geormo', 'jibril@gmail.com', '089876543210', 'Jl. Melati No. 45', 'phone', 'apartment', 45, 'Apartemen Melati Tower A, Lt. 5', '2025-11-19 20:54:45', '2025-11-19 20:54:45'),
(3, 'Yunus Bakrie', 'yunus@gmail.com', '081223344556', 'Jl. Kenanga No. 9', 'email', 'office', 200, 'Perkantoran Kenanga Lt. 2', '2025-11-19 20:54:45', '2025-11-19 20:54:45'),
(4, 'Bahliel Kuoptore', 'bahliel@gmail.com', '082112233445', 'Jl. Sudirman No. 20', 'whatsapp', 'house', 100, 'Jl. Sudirman No. 20, Depok', '2025-11-19 20:54:45', '2025-11-19 20:54:45'),
(5, 'Linda Supratna', 'linda@gmail.com', '085123456789', 'Jl. Mawar No. 18', 'whatsapp', 'apartment', 38, 'Apartemen Mawar Tower B Lt. 10', '2025-11-19 20:54:45', '2025-11-19 20:54:45');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_code` varchar(30) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `status` enum('active','inactive','on_leave') DEFAULT 'active',
  `rating` decimal(3,2) DEFAULT 0.00,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `address` mediumtext DEFAULT NULL,
  `emergency_contact_name` varchar(100) DEFAULT NULL,
  `emergency_contact_phone` varchar(20) DEFAULT NULL,
  `skills` mediumtext DEFAULT NULL,
  `total_jobs_completed` int(11) DEFAULT 0,
  `certifications` mediumtext DEFAULT NULL,
  `shift_date` date DEFAULT NULL,
  `shift_start` time DEFAULT NULL,
  `shift_end` time DEFAULT NULL,
  `shift_type` enum('morning','afternoon','evening','full') DEFAULT 'full',
  `work_status` enum('scheduled','completed','cancelled') DEFAULT 'scheduled',
  `hired_at` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `employee_code`, `name`, `position`, `status`, `rating`, `phone`, `email`, `password`, `photo`, `address`, `emergency_contact_name`, `emergency_contact_phone`, `skills`, `total_jobs_completed`, `certifications`, `shift_date`, `shift_start`, `shift_end`, `shift_type`, `work_status`, `hired_at`, `created_at`, `updated_at`) VALUES
(1, 'EMP-001', 'Enjel Saputra', 'Regular Cleaner', 'active', 4.60, '081234567890', 'enjel.cleanify@mail.com', NULL, NULL, 'Jl. Melati No. 10, Bandung', 'Merin Julianto', '081200000111', 'Sapu & Pel, Lap Debu, Kaca Kecil', 0, 'Basic Cleaning Certification', '2025-01-20', '08:00:00', '12:00:00', 'morning', 'scheduled', '2024-05-12', '2025-11-19 19:51:56', '2025-11-19 20:56:16'),
(2, 'EMP-002', 'Redup Mayern', 'Deep Clean Specialist', 'active', 4.80, '081298765432', 'redup.cleanify@mail.com', NULL, NULL, 'Jl. Sukajadi No. 50, Bandung', 'Budi Saputra', '081299998888', 'Deep Clean, Vacuum, Kitchen & Bathroom Expert', 0, 'Deep Clean Pro Level 2', '2025-01-20', '13:00:00', '17:00:00', 'afternoon', 'scheduled', '2023-11-02', '2025-11-19 19:51:56', '2025-11-19 20:59:47'),
(3, 'EMP-003', 'Amita Bacan', 'Premium Senior Staff', 'on_leave', 4.90, '081277744455', 'amita.cleanify@mail.com', NULL, NULL, 'Jl. Dago Pakar No. 11, Bandung', 'Ardi Susanto', '081311112222', 'Detailing, Aromatherapy Setup, VIP Handling, Eco Cleaning', 0, 'Premium Service Certification', '2025-01-25', '07:00:00', '15:00:00', 'full', 'scheduled', '2022-09-18', '2025-11-19 19:51:56', '2025-11-19 19:51:56');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_code` varchar(30) DEFAULT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `service_id` bigint(20) UNSIGNED NOT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `scheduled_date` date DEFAULT NULL,
  `scheduled_start_time` time DEFAULT NULL,
  `scheduled_end_time` time DEFAULT NULL,
  `total_cost` decimal(12,2) NOT NULL,
  `status` enum('baru','dikonfirmasi','dalam_proses','selesai','dibatalkan') DEFAULT 'baru',
  `payment_proof` varchar(255) DEFAULT NULL,
  `payment_confirmed_at` datetime DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `finish_time` datetime DEFAULT NULL,
  `customer_rating` int(11) DEFAULT NULL,
  `customer_feedback` text DEFAULT NULL,
  `cancellation_reason` text DEFAULT NULL,
  `cancelled_by` varchar(100) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_code`, `customer_id`, `service_id`, `order_date`, `scheduled_date`, `scheduled_start_time`, `scheduled_end_time`, `total_cost`, `status`, `payment_proof`, `payment_confirmed_at`, `start_time`, `finish_time`, `customer_rating`, `customer_feedback`, `cancellation_reason`, `cancelled_by`, `cancelled_at`, `created_at`, `updated_at`) VALUES
(17, 'ORD-20250101-001', 1, 1, '2025-01-01 10:20:00', NULL, NULL, NULL, 75000.00, 'baru', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-19 21:00:58', '2025-11-19 21:00:58'),
(18, 'ORD-20250102-002', 2, 2, '2025-01-02 08:45:00', '2025-01-05', '09:00:00', '12:00:00', 150000.00, 'dikonfirmasi', 'Bukti transfer #A73819', '2025-01-02 09:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-19 21:00:58', '2025-11-19 21:00:58'),
(19, 'ORD-20250103-003', 3, 1, '2025-01-03 13:00:00', '2025-01-06', '14:00:00', '15:00:00', 75000.00, 'dalam_proses', 'DP 50% diterima', '2025-01-03 13:10:00', '2025-01-06 14:00:00', NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-19 21:00:58', '2025-11-19 21:00:58'),
(20, 'ORD-20250104-004', 1, 3, '2025-01-04 09:00:00', '2025-01-04', '10:00:00', '13:00:00', 250000.00, 'selesai', 'Pembayaran selesai', '2025-01-04 09:30:00', '2025-01-04 10:00:00', '2025-01-04 13:00:00', 5, 'Customer sangat puas', NULL, NULL, NULL, '2025-11-19 21:00:58', '2025-11-19 21:00:58'),
(21, 'ORD-20250105-005', 4, 1, '2025-01-05 11:20:00', '2025-01-07', '08:00:00', '09:30:00', 75000.00, 'dibatalkan', NULL, NULL, NULL, NULL, NULL, NULL, 'Customer membatalkan karena hujan', 'customer', '2025-01-05 12:00:00', '2025-11-19 21:00:58', '2025-11-19 21:00:58'),
(22, 'ORD-20250106-006', 5, 2, '2025-01-06 16:10:00', NULL, NULL, NULL, 150000.00, 'baru', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-19 21:00:58', '2025-11-19 21:00:58'),
(23, 'ORD-20250107-007', 3, 3, '2025-01-07 07:50:00', '2025-01-07', '08:00:00', '12:00:00', 250000.00, 'dalam_proses', 'Sudah lunas', '2025-01-07 07:55:00', '2025-01-07 08:00:00', NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-19 21:00:58', '2025-11-19 21:00:58'),
(24, 'ORD-20250108-008', 2, 1, '2025-01-08 14:30:00', '2025-01-08', '15:00:00', '16:00:00', 75000.00, 'selesai', 'Pembayaran diterima', '2025-01-08 14:45:00', '2025-01-08 15:00:00', '2025-01-08 16:00:00', 4, 'Bersih dan rapi', NULL, NULL, NULL, '2025-11-19 21:00:58', '2025-11-19 21:00:58');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `schedule_date` date NOT NULL,
  `time_slot_start` time NOT NULL,
  `time_slot_end` time NOT NULL,
  `status` enum('scheduled','in_progress','completed','cancelled') DEFAULT 'scheduled',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `employee_id`, `order_id`, `schedule_date`, `time_slot_start`, `time_slot_end`, `status`, `notes`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, '2025-01-21', '08:00:00', '11:00:00', 'scheduled', 'Cleaning apartemen kecil', '2025-11-19 20:05:21', '2025-11-19 20:05:21'),
(2, 2, NULL, '2025-01-21', '13:00:00', '17:00:00', 'scheduled', 'Deep clean kitchen & bathroom', '2025-11-19 20:05:21', '2025-11-19 20:05:21'),
(3, 3, NULL, '2025-01-21', '08:00:00', '16:00:00', 'scheduled', 'Premium cleaning VIP customer', '2025-11-19 20:05:21', '2025-11-19 20:05:21');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` enum('regular','deep_clean','premium') NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `duration_minutes` int(11) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `short_description` varchar(255) DEFAULT NULL,
  `full_description` mediumtext DEFAULT NULL,
  `features` mediumtext DEFAULT NULL,
  `not_included` mediumtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `category`, `price`, `duration_minutes`, `status`, `short_description`, `full_description`, `features`, `not_included`, `created_at`, `updated_at`) VALUES
(1, 'Regular Cleaning', 'regular', 50000.00, 45, 'active', 'Pembersihan standar untuk kamar kecil', 'Termasuk sapu, pel, lap debu, membersihkan kaca kecil, dan merapikan barang', 'Sapu dan pel, Lap debu, Bersih kaca kecil, Desinfektan ringan', 'Tidak termasuk mencuci karpet, tidak termasuk deep clean', '2025-11-19 19:31:54', '2025-11-19 19:31:54'),
(2, 'Deep Cleaning', 'deep_clean', 120000.00, 120, 'active', 'Pembersihan mendalam untuk seluruh ruangan', 'Termasuk pembersihan detail, mengangkat furnitur ringan, desinfeksi kuat, pembersihan sudut-sudut sulit', 'Alat khusus, Chemical khusus, Pembersihan mendalam', 'Tidak termasuk perbaikan furnitur atau bongkar besar', '2025-11-19 19:32:48', '2025-11-19 19:32:48'),
(3, 'Premium Cleaning', 'premium', 200000.00, 180, 'active', 'Layanan premium dengan hasil maksimal', 'Termasuk layanan lengkap, bahan pembersih eco-friendly, pembersihan menyeluruh dan detail', 'Eco-friendly chemicals, Senior staff, Finishing wangi premium', 'Tidak termasuk deep restore berat', '2025-11-19 19:33:55', '2025-11-19 19:33:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin','cleaner') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `role`, `created_at`, `updated_at`) VALUES
(1, 'redup', 'redup', 'refiansyah415@gmail.com', '$2y$10$5NvubLDnCPQe3W7HO/kxm.UxH6IoDuYt/84zMxub1M4KbUVLwPAxm', 'user', '2025-11-06 02:25:50', '2025-11-06 02:25:50'),
(3, '', 'wonder of u', 'redup47@gmail.com', '$2y$10$x8KsP4n794bfAjJdSE3kduDZTpTBpjWh/uvLS8M00LbPZeV3MlAK2', 'user', '2025-11-19 17:33:29', '2025-11-19 17:33:29'),
(10, '', 'mk', 'mk@gmail.com', '$2y$10$RDrHZzFzrfMWdKz.EyNzhOAcITCeF5gTjl70hqShLZQzRgdmQh/Ia', 'user', '2025-11-11 01:31:08', '2025-11-11 01:31:08'),
(11, '', 'kharista', 'kharista@gmail.com', '$2y$10$B/ioL2m18KPFPaGUdMjVc.QyIhtJbGwJwyZwKz2k65/EIGA0yWe5.', 'user', '2025-11-11 01:32:33', '2025-11-11 01:32:33'),
(12, 'Merin Kharista Putri', 'merinkp', 'merin@gmail.com', '$2y$10$B/ioL2m18KPFPaGUdMjVc.QyIhtJbGwJwyZwKz2k65/EIGA0yWe5.', 'cleaner', '2025-11-11 01:50:11', '2025-11-11 01:50:11'),
(16, 'Admin ', 'admin', 'admin@gmail.com', '$2y$10$ZU/lIt7vfQzraLJZbYxoE.w84mT8jmV1M1JxQ41D/gAUkF5ABjwUm', 'admin', '2025-11-11 02:02:30', '2025-11-11 02:02:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `employee_code` (`employee_code`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `service_id` (`service_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`);

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `schedules_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
